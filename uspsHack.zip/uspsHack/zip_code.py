import requests
import xml.etree.ElementTree as ET

def get_zip(addr):
    try:
        print("received addr by pree: ",addr)
        #addr1 = addr.split(",")
        print("split pree addr, ",addr)
        addr1=addr
        if(len(addr1)==0):
            return "-1"
        test_url1 = 'http://production.shippingapis.com/ShippingAPITest.dll?API=Verify&XML=<AddressValidateRequest USERID="970SANJO6946">' \
                    '<Address ID="0"><Address1></Address1><Address2>' \
                    + addr1[0].strip() + \
                    '</Address2><City>' \
                    + addr1[1].strip() + \
                    '</City><State>' \
                    + addr1[2].strip() + \
                    '</State><Zip5></Zip5><Zip4></Zip4></Address></AddressValidateRequest>'
        print("before req pree: ", addr)
        print("test url : ",test_url1)
        resu = requests.get(test_url1)
        print("resu.content: ",resu.content)
        root = ET.fromstring(resu.content)
        print("root from getZip , ",root)
        resp_zip = root[0][3].text
        print("resp_zip ",resp_zip)
        return resp_zip
    except Exception:
        return "0"
