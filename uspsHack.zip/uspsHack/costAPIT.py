import requests
import xml.etree.ElementTree as ET

def get_cost(sourceZip, destinationZip):
    print("sender ",sourceZip)
    print("receiver ",destinationZip)
    URL_api = "http://production.shippingapis.com/ShippingAPI.dll?API=RateV4&XML=%3CRateV4Request%20USERID=%22970SANJO6946%22%3E%20%3CRevision%3E2%3C/Revision%3E%20%3CPackage%20ID=%221ST%22%3E%20%3CService%3EFIRST%20CLASS%3C/Service%3E%20%3CFirstClassMailType%3ELETTER%3C/FirstClassMailType%3E%20%3CZipOrigination%3E"+str(sourceZip)+"%3C/ZipOrigination%3E%20%3CZipDestination%3E"+str(destinationZip)+"%3C/ZipDestination%3E%20%3CPounds%3E0%3C/Pounds%3E%20%3COunces%3E10%3C/Ounces%3E%20%3CContainer/%3E%20%3CSize%3EREGULAR%3C/Size%3E%20%3CMachinable%3Etrue%3C/Machinable%3E%20%3C/Package%3E%20%3C/RateV4Request%3E"
    response = requests.get(URL_api)
    response_content=response.content
    print(response_content)
    print("url api:, ", URL_api)
    root = ET.fromstring(response_content)
    print("root 0 ", root[0])
    print("root ",root[0][8])
    rate= float(root[0][8][1].text)
    return rate

#print("The cost from source to destination is ",get_cost(95110,10005))