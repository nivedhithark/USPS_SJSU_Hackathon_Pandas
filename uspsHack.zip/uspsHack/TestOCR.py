import userImageTodigiData as uid

def callOCR():
    path = 'uploadsOCR/testdataOCR.png'
    uid.imgToExcel(path)