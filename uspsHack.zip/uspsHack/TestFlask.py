from flask import Flask, render_template, request, jsonify, send_file

import testChatter
import os
import TestOCR as testOCR
import costAPIT as testCost
import csv
import zip_code
import weather as testWeather

app = Flask(__name__)
UPLOAD_FOLDER = os.path.basename('uploadsOCR')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/geocode')
def get_data():
    #events = api.call(get_event, arg0, arg1)
    #geocode = event['latitude'], event['longitude']
    geocode = 1234, 5678
    return render_template('js_array.html', geocode=geocode)

@app.route('/uploadOCR', methods=['POST'])
def uploadOCR():
    file = request.files['image']
    f = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    # add your custom code to check that the uploaded file is a valid image and not a malicious file (out-of-scope for this post)
    file.save(f)
    testOCR.callOCR()
    return ('', 204);

@app.route('/downloadsOCR')
def downloadOCR():
    try:
        return send_file(r'C:\Users\nived\PycharmProjects\uspsHack\downloadsOCR\ocrdata.csv',
                         attachment_filename='ocrdata.csv')
    except Exception as e:
        return str(e)

@app.route('/callChatBot')
def callChatBot():
    print("request is: ",request.args)
    a = request.args.get('question');
    print("a is: ",a)
    chatBotOutput =  testChatter.chat(a);
    print("chat bot op ", chatBotOutput)
    return jsonify(answer=str(chatBotOutput));


def getAddresses():
    addr = []
    with open("ocrdata.csv", newline='') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        data=[]
        for row in reader:
            data.append(row)
        f.close()
        #addr.append(data[-1][2])
        #addr.append(data[-1][5])
        addr.append(data[-1][2].split(","))
        addr.append(data[-1][5].split(","))
    return addr

@app.route('/estimateCost')
def estimateCost():
    addrs = getAddresses()
    print("addresses in estimateCost ",addrs)
    source_zip = zip_code.get_zip(addrs[0])
    if(source_zip=="-1"):
        return('estimatedCostValue',"$0")
    dest_zip=zip_code.get_zip(addrs[1])
    cost = testCost.get_cost(source_zip,dest_zip);
    print("final cost: ",cost)
    str_cost = "$"+str(cost)
    print("final: ",str_cost)
    return jsonify(estimatedCostValue=str_cost);


@app.route('/estimateWeather')
def estimateWeather():
    addrs = getAddresses()
    dest_zip = zip_code.get_zip(addrs[1])
    weathers = testWeather.get_weather(dest_zip);
    return jsonify(estimatedWeatherMain=weathers['main'],estimatedWeatherDesc=weathers['desc']);

if __name__ == '__main__':
  app.run(host='0.0.0.0')