from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer, ChatterBotCorpusTrainer



usps_trainer_file_path = r"C:\Users\nived\PycharmProjects\uspsHack\custom2.txt"
chatbot = ChatBot('Usps2')

def chat_train():

    #trainer = ChatterBotCorpusTrainer(chatbot)
    trainer = ListTrainer(chatbot)

    data = open(usps_trainer_file_path).read()
    conversations = data.strip().split('\n')
    trainer.train(conversations)

    # Create a new trainer for the chatbot
    trainer = ChatterBotCorpusTrainer(chatbot)

    # Train the chatbot based on the english corpus
    trainer.train("chatterbot.corpus.english")



def chat(input):
    # Get a response to an input statement
    #chat_train()
    return chatbot.get_response(input)

#must train only once
#chat_train()

print(chat("How do I file tax?"))