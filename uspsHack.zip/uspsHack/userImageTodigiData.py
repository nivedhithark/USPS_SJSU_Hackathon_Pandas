
##all image types are supported. Example: png, jpeg, gif, tiff, bmp
#import Image
import time
from PIL import Image
#from tesseract import image_to_string
from pytesseract import image_to_string
import csv
import os
import numpy as np

def imgToExcel(path):
    imageData = image_to_string(Image.open(path), lang='eng')
    splitData = imageData.split("\n")
    dataDict = {}

    for line in splitData:

        if (len(line) != 0):
            temp = line.split(':')
            # print(temp[0],'temp0')
            # print(temp[1], 'temp1')
            dataDict[temp[0].strip().replace(" ", "").lower()] = temp[1].strip()

    if (len(dataDict) == 6):

        costpaid = True  ##need to make it dynamic
        entrytime = time.time()
        exists = os.path.isfile('ocrdata.csv')
        if not exists:
            with open('ocrdata.csv', 'w', newline='') as csvHead:
                writer = csv.writer(csvHead)
                header = ['trackingid', 'sendername', 'senderaddress', 'senderphone', 'receivername', 'receiveraddress',
                          'receiverphone', 'costpaid', 'entrytime']
                writer.writerow(header)
            csvHead.close()
            trackingid = 1
            row = [str(trackingid), str(dataDict['sendername']), str(dataDict['senderaddress']),
                   str(dataDict['senderphone']), str(dataDict['receivername']),
                   dataDict['receiveraddress'], dataDict['receiverphone'], costpaid, entrytime]
            with open('ocrdata.csv', 'a', newline='') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerow(row)
                # writer.writerow("\n")

            csvFile.close()
        else:
            trackingid = 0
            with open("ocrdata.csv", newline='') as f:
                reader = csv.reader(f)
                next(reader)  # skip header
                data = []
                for row in reader:
                    data.append(row)
                f.close()
                trackingid = int(data[-1][0]) + 1

            row = [str(trackingid), str(dataDict['sendername']), str(dataDict['senderaddress']),
                   str(dataDict['senderphone']), str(dataDict['receivername']),
                   dataDict['receiveraddress'], dataDict['receiverphone'], costpaid, entrytime]
            print("data printing", int(data[-1][0]))
            with open('ocrdata.csv', 'a', newline='') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerow(row)
                # writer.writerow("\n")

            #writing excel in downloads OCR
            with open('downloadsOCR/ocrdata.csv', 'a', newline='') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerow(row)
                # writer.writerow("\n")
            csvFile.close()
    print("splitt")
    print(len(dataDict))
    # print(image_to_string(Image.open('inputImages/testdata.png'), lang='eng'))

