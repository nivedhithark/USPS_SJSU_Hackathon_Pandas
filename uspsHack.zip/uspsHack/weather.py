
import requests,json

def get_weather(zip):
    url = 'https://samples.openweathermap.org/data/2.5/weather?zip='+str(zip).strip()+',us&appid=b6907d289e10d714a6e88b30761fae22'
    result = requests.get(url)
    main_res = json.loads(result.content)
    req_data = {}
    #print(main_res)
    req_data['main'] = main_res['weather'][0]['main']
    req_data['desc'] = main_res['weather'][0]['description']
    return req_data

print(get_weather(95110))