$(function(){
$("#addClass").click(function () {
          $('#qnimate').addClass('popup-box-on');
            });

            $("#removeClass").click(function () {
          $('#qnimate').removeClass('popup-box-on');
            });
  });


$(function(){
$("#btn-chat").click(function(){
var x = $('input[name="btn-input"]').val();
console.log(x);
$.getJSON('/callChatBot', {
question:x
}, function(data){
$("#outputToUser").text(data.answer);
});
})
});


$(function(){
$.getJSON('/estimateWeather', function(data){
$('#estimatedWeather').text(data.estimatedWeatherMain+"("+data.estimatedWeatherDesc+")");
});
});

$(function(){
$.getJSON('/estimateCost', function(data){
$("#estimatedCostValue").text(data.estimatedCostValue);
});
});

